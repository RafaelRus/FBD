DROP TABLE MARCA_MODELO CASCADE CONSTRAINTS; 
DROP TABLE PERSONA CASCADE CONSTRAINTS; 
DROP TABLE CONDUCTOR CASCADE CONSTRAINTS; 
DROP TABLE DUENO CASCADE CONSTRAINTS; 
DROP TABLE VEHICULO CASCADE CONSTRAINTS;
DROP TABLE CONDUCTOR_HABITUAL CASCADE CONSTRAINTS; 
DROP TABLE CARRETERA CASCADE CONSTRAINTS;
DROP TABLE OBSERVACION CASCADE CONSTRAINTS; 
DROP TABLE RADAR CASCADE CONSTRAINTS;
DROP TABLE INFRACCION_COMETIDA CASCADE CONSTRAINTS; 
DROP TABLE SANCION CASCADE CONSTRAINTS;
DROP TABLE ALEGACION CASCADE CONSTRAINTS;
CREATE TABLE MARCA_MODELO(
	marca VARCHAR2(10),
	modelo VARCHAR2(12),
	potencia NUMBER(4) NOT NULL,
	CONSTRAINT MARCA_MODELO_PK PRIMARY KEY (marca,modelo)
);
CREATE TABLE PERSONA(
	dni VARCHAR2(9),
	nombre VARCHAR2(35) NOT NULL,
	apellido1 VARCHAR2(18) NOT NULL,
	apellido2 VARCHAR2(18),
	direc_postal VARCHAR2(42) NOT NULL,
	localidad VARCHAR2(35) NOT NULL,
	telefono NUMBER(9),
	email VARCHAR2(50),
	CONSTRAINT PERSONA_PK PRIMARY KEY (dni),
	CONSTRAINT CH_PERSONA CHECK (email LIKE '%@%.%' OR email IS NULL) 
);
CREATE TABLE CONDUCTOR(
	persona_c VARCHAR2(9), 
	fe_nacimientoconductor DATE NOT NULL, 
	tipo_carnet VARCHAR2(3) NOT NULL, 
	fe_emision DATE NOT NULL,
	CONSTRAINT CONDUCTOR_PK PRIMARY KEY (persona_c),
	CONSTRAINT FK_CONDUCTOR FOREIGN KEY (persona_c) REFERENCES PERSONA (dni) ON DELETE CASCADE
);
CREATE TABLE DUENO(
	persona_d VARCHAR2(9),
	fe_nacimientodueno DATE NOT NULL,
	CONSTRAINT DUENO_PK PRIMARY KEY (persona_d),
	CONSTRAINT FK_DUENO FOREIGN KEY (persona_d) REFERENCES PERSONA (dni) ON DELETE CASCADE
);
CREATE TABLE VEHICULO(
	matricula VARCHAR2(7),
	num_bastidor VARCHAR2(17),
	marca_v VARCHAR2(10),
	modelo_v VARCHAR2(12),
	color VARCHAR2(25) NOT NULL,
	fe_matriculacion DATE NOT NULL,
	fe_ultimaitv DATE NOT NULL,
	dueno_v	VARCHAR2(9),
	CONSTRAINT VEHICULO_UK UNIQUE (num_bastidor), 
	CONSTRAINT VEHICULO_PK PRIMARY KEY (matricula),
	CONSTRAINT CK1_VEHICULO CHECK (fe_matriculacion <= fe_ultimaitv), 
	CONSTRAINT FK1_VEHICULO FOREIGN KEY (marca_v,modelo_v) REFERENCES MARCA_MODELO (marca,modelo),
	CONSTRAINT FK2_VEHICULO FOREIGN KEY (dueno_v) REFERENCES DUENO (persona_d)
);
CREATE TABLE CONDUCTOR_HABITUAL(
	vehiculo VARCHAR2(7),
	conductor VARCHAR2(9),
	CONSTRAINT CONDUCTOR_HABITUAL_PK PRIMARY KEY (vehiculo,conductor), 
	CONSTRAINT FK1_CONDUCTOR_HABITUAL FOREIGN KEY (vehiculo) REFERENCES VEHICULO (matricula) ON DELETE CASCADE,
	CONSTRAINT FK2_CONDUCTOR_HABITUAL FOREIGN KEY (conductor) REFERENCES CONDUCTOR (persona_c) ON DELETE CASCADE
);
CREATE TABLE CARRETERA(
	id_carretera VARCHAR2(5),
	lim_velocidad NUMBER(3) NOT NULL,
	CONSTRAINT CARRETERA_PK PRIMARY KEY (id_carretera)
);	
CREATE TABLE RADAR(	
	carretera VARCHAR2(5),
	sentido VARCHAR2(3),
	punto_kilometrico NUMBER(3),
 	velocidadlim NUMBER(3), 
	CONSTRAINT RADAR_PK PRIMARY KEY (carretera, sentido, punto_kilometrico,velocidadlim), 
	CONSTRAINT CK_RADAR CHECK ((sentido IN ('ASC','DES'))),
	CONSTRAINT FK_RADAR FOREIGN KEY (carretera) REFERENCES CARRETERA (id_carretera) ON DELETE CASCADE
);
CREATE TABLE OBSERVACION(
	radar_c	VARCHAR2(9),
	radar_s	VARCHAR2(3),
	radar_punto_kilometro NUMBER(3),
	radar_velocidadlim NUMBER(3),
	fecha_hora TIMESTAMP,
	veh VARCHAR2(7),
	velocidadpuntual_vehiculo NUMBER(3) NOT NULL,
	CONSTRAINT OBSERVACION_PK PRIMARY KEY (radar_c,radar_s,radar_punto_kilometro,radar_velocidadlim,fecha_hora),
	CONSTRAINT CK1_OBSERVACION CHECK (velocidadpuntual_vehiculo > 0), 
	CONSTRAINT CK2_OBSERVACION CHECK ((radar_s IN ('ASC','DES'))),
	CONSTRAINT FK1_OBSERVACION FOREIGN KEY (radar_c,radar_s,radar_punto_kilometro,radar_velocidadlim) REFERENCES RADAR (carretera,sentido,punto_kilometrico,velocidadlim),
	CONSTRAINT FK2_OBSERVACION FOREIGN KEY (veh) REFERENCES VEHICULO (matricula) ON DELETE CASCADE
);
CREATE TABLE INFRACCION_COMETIDA(
	obs_radar_c VARCHAR2(9),
	obs_radar_s VARCHAR2(3),
	obs_radar_punto_kilometro NUMBER(3),
	obs_radar_velocidadlim NUMBER(3),
	obs_fecha_hora TIMESTAMP,
	tipo_infraccion	VARCHAR2(3) NOT NULL,
	CONSTRAINT CK1_INFRACCION_COMETIDA CHECK ((tipo_infraccion IN ('VPM','NDS','NLS'))),
	CONSTRAINT CK2_INFRACCION_COMETIDA CHECK ((obs_radar_s IN ('ASC','DES'))),
	CONSTRAINT INFRACCION_COMETIDA_PK PRIMARY KEY (obs_radar_c,obs_radar_s,obs_radar_punto_kilometro,obs_radar_velocidadlim,obs_fecha_hora),	
	CONSTRAINT FK_INFRACCION_COMETIDA FOREIGN KEY (obs_radar_c,obs_radar_s,obs_radar_punto_kilometro,obs_radar_velocidadlim,obs_fecha_hora) REFERENCES OBSERVACION (radar_c,radar_s,radar_punto_kilometro,radar_velocidadlim,fecha_hora)
);
CREATE TABLE SANCION(
	inf_radar_c VARCHAR2(9),
	inf_radar_s VARCHAR2(3),
	inf_punto_kilometro NUMBER(3),
	inf_velocidadlim NUMBER(3),
	inf_fecha_hora TIMESTAMP,
	pagador	VARCHAR2(9),
	fe_envio DATE,
	femax_pago DATE,
 	importe	NUMBER(6,2) NOT NULL,
	forma_pago VARCHAR2(10),
	CONSTRAINT SANCION_PK PRIMARY KEY (inf_radar_c,inf_radar_s,inf_punto_kilometro,inf_velocidadlim,inf_fecha_hora),
	CONSTRAINT CK1_SANCION CHECK (fe_envio <= femax_pago),
	CONSTRAINT CK3_SANCION CHECK ((inf_radar_s IN ('ASC','DES'))),
	CONSTRAINT FK1_SANCION FOREIGN KEY (pagador) REFERENCES PERSONA (dni),
	CONSTRAINT FK2_SANCION FOREIGN KEY (inf_radar_c,inf_radar_s,inf_punto_kilometro,inf_velocidadlim,inf_fecha_hora) REFERENCES INFRACCION_COMETIDA (obs_radar_c,obs_radar_s,obs_radar_punto_kilometro,obs_radar_velocidadlim,obs_fecha_hora) 
);
CREATE TABLE ALEGACION(
	sa_radar_c VARCHAR2(9),
	sa_radar_s VARCHAR2(3),
	sa_radar_punto_kilometro NUMBER(3),
	sa_radar_velocidadlim NUMBER(3),
	sa_fecha_hora TIMESTAMP,
	conductor_nuevosancionado VARCHAR2(9),
	fe_registro DATE,	
	estado_a VARCHAR2(1),
	fe_ejecucion DATE,
	CONSTRAINT CK1_ALEGACION CHECK (fe_registro <= fe_ejecucion),
	CONSTRAINT CK2_ALEGACION CHECK ((estado_a IN ('A','R','E'))), 
	CONSTRAINT CK3_ALEGACION CHECK ((sa_radar_s IN ('ASC','DES'))), 
	CONSTRAINT ALEGACION_PK PRIMARY KEY (sa_radar_c,sa_radar_s,sa_radar_punto_kilometro,sa_radar_velocidadlim,sa_fecha_hora),
	CONSTRAINT FK1_ALEGACION FOREIGN KEY (conductor_nuevosancionado) REFERENCES CONDUCTOR (persona_c),
	CONSTRAINT FK2_ALEGACION FOREIGN KEY (sa_radar_c,sa_radar_s,sa_radar_punto_kilometro,sa_radar_velocidadlim,sa_fecha_hora) REFERENCES SANCION (inf_radar_c,inf_radar_s,inf_punto_kilometro,inf_velocidadlim,inf_fecha_hora) ON DELETE CASCADE
);